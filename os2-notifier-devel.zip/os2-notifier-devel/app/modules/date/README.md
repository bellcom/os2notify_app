date
====

The DrupalGap Date module.
